﻿using OOO_Sport_Product.Classes;
using OOO_SportProduct.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OOO_Sport_Product.View
{
    /// <summary>
    /// Логика взаимодействия для WorkOrder.xaml
    /// </summary>
    public partial class WorkOrder : Window
    {
        public WorkOrder()
        {
            InitializeComponent();
        }

        //Список всех заказов из БД
        List<OOO_SportProducts.Model.Order> listOrders = new List<OOO_SportProducts.Model.Order>();
        //Список заказанных товаров
        List<OOO_SportProducts.Model.OrderProduct> listProductsInOrders = new List<OOO_SportProducts.Model.OrderProduct>();
        //Список заказанных товаров с дополнительными свойствами
        List<Classes.OrderExtended> listExtendedOrders;

        Classes.OrderExtended selectOrder;		//Выбранный заказ


        /// При загрузке окна
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //Список статусов заказа
            cbStatus.ItemsSource = Helper.dBSportEntities.Status.ToList();
            cbStatus.DisplayMemberPath = "StatusName";
            cbStatus.SelectedValuePath = "StatusID";
            cbSort.SelectedIndex = 0;
            //cbFilterDiscount.ItemsSource = new List<string>() { "Все диапазоны", "До 3%", "От 3 до 5%", "От 5%" };
            //cbFilterDiscount.SelectedIndex = 0;
            ShowOrders();

        }

        /// Метод отображает информацию о заказах с дополнительными свойствами
        /// </summary>
        private void ShowOrders()
        {
            listOrders = Helper.dBSportEntities.Order.ToList();	//Получить все заказы
            int totalCount = listOrders.Count;		//Их общее количество
            listProductsInOrders = Helper.dBSportEntities.OrderProduct.ToList(); //Получить все заказанные товары
            //Создание списка заказанных товаров с расширенными свойствами
            listExtendedOrders = new List<OrderExtended>();
            foreach (var order in listOrders)
            {
                Classes.OrderExtended orderExtended = new OrderExtended();
                orderExtended.Order = order;		//Заполнить данные о заказе из БД
                //Вызов методов класса через объект для вычисления дополнительных свойств
                orderExtended.TotalSumma = orderExtended.CalcTotalSummma(listProductsInOrders);
                orderExtended.TotalDiscount = orderExtended.CalcTotalDiscount(listProductsInOrders);
                listExtendedOrders.Add(orderExtended);
            }

            if (cbFilterDiscount != null)
            {
                if (cbFilterDiscount.SelectedIndex == 1)
                    listExtendedOrders = listExtendedOrders.Where(order => order.TotalDiscountPercent < 3).ToList();
                else if (cbFilterDiscount.SelectedIndex == 2)
                    listExtendedOrders = listExtendedOrders.Where(order => order.TotalDiscountPercent > 2.99 && order.TotalDiscountPercent < 5).ToList();
                else if (cbFilterDiscount.SelectedIndex == 3)
                    listExtendedOrders = listExtendedOrders.Where(order => order.TotalDiscountPercent > 4.99).ToList();
            }

            //Сортировка
            switch (cbSort.SelectedIndex)
            {
                case 1:
                    listExtendedOrders = listExtendedOrders.OrderBy(or => or.TotalSumma).ToList();
                    break;
                case 2:
                    listExtendedOrders =
                                       listExtendedOrders.OrderByDescending(or => or.TotalSumma).ToList();
                    break;
            }
            //Отображение информации о заказах
            int filterCount = listExtendedOrders.Count;
            listViewOrders.ItemsSource = null;
            listViewOrders.ItemsSource = listExtendedOrders;
            tbCount.Text = filterCount + " из " + totalCount;
        }

        /// Метод создает список заказанных товаров только для конкретного заказа
        /// <param name="orderId"> Номер заказа</param>
        /// <returns>Построенный список из товаров в заказе</returns>
        public List<OOO_SportProducts.Model.OrderProduct> ListProductsInOrderId(int orderId)
        {
            List<OOO_SportProducts.Model.OrderProduct> list = new List<OOO_SportProducts.Model.OrderProduct>();
            //Поиск всех товаров для выбранного номера заказа
            list = listProductsInOrders.FindAll(pr => pr.OrderID == orderId).ToList();
            return list;
        }


        /// Выбор заказа в списке заказов
        private void listViewOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Проверка, что есть выбранный заказ
            if (listViewOrders.SelectedItem == null)
                return;
            //Получение всей информации о выбранном заказе
            selectOrder = listViewOrders.SelectedItem as Classes.OrderExtended;
            //Формирование списка товаров в этом заказе по разработанному методу
            List<OOO_SportProducts.Model.OrderProduct> listTemp = ListProductsInOrderId(selectOrder.Order.OrderID);
            //Отображение товаров выбранного заказа
            listViewOrder.ItemsSource = listTemp;
            //Отобразить статус заказа
            cbStatus.SelectedValue = selectOrder.Order.OrderStatus;
            //Отобразить дату доставки заказа
            dateDelivery.SelectedDate = selectOrder.Order.OrderDelivery;
            ShowOrders();

        }

        /// Выбор направления сортировки
        private void cbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ShowOrders();
        }

        /// Выбор условия фильтрации
        private void cbFilterDiscount_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ShowOrders();
        }

        /// Сохранение в таблицу Order БД изменений о заказе
        private void butEditOrder_Click(object sender, RoutedEventArgs e)
        {
            //Есть выбранный заказ для редактирования
            if (selectOrder != null)
            {
                //Получить объект модели заказа
                OOO_SportProducts.Model.Order order = selectOrder.Order;
                //Задать новые значения для даты доставки и статуса
                order.OrderDelivery = (DateTime)dateDelivery.SelectedDate;
                order.OrderStatus = (int)cbStatus.SelectedValue;
                try
                {
                    Helper.dBSportEntities.SaveChanges();		//Сохранение в БД
                    MessageBox.Show("Данные успешно обновлены");
                    ShowOrders();
                }
                catch
                {
                    MessageBox.Show("При обновлении данных возникли проблемы");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Не выбран редактируемый заказ");
            }
        }

        private void buttonNavigate_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

}

